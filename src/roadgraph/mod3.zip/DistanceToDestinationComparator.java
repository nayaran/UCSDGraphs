package roadgraph;

import java.util.Comparator;

public class DistanceToDestinationComparator implements Comparator<MapNode> {

	@Override
	public int compare(MapNode o1, MapNode o2) {
		return (int) (o1.getEstimatedDistanceToDestination() - o2.getEstimatedDistanceToDestination());
	}

}
