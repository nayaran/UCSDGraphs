package roadgraph;

import java.util.LinkedList;
import java.util.List;

import geography.GeographicPoint;

public class MapNode {
	private GeographicPoint geoPoint;
	private List<MapEdge> outRoads;
	
	public MapNode(GeographicPoint geoPoint) {
		this.geoPoint = geoPoint;
		this.outRoads = new LinkedList<MapEdge>();
	}

	public List<GeographicPoint> getNeighbors() {
		List<GeographicPoint> neighbors = new LinkedList<GeographicPoint>();
		
		for (MapEdge road: outRoads) {
			neighbors.add(road.getDestination());
		}
		return neighbors;
	}
	
	void addOutRoad(MapEdge outRoad) {
		outRoads.add(outRoad);
	}
	
	public GeographicPoint getGeoPoint() {
		return geoPoint;
	}
	public void setGeoPoint(GeographicPoint geoPoint) {
		this.geoPoint = geoPoint;
	}
	public List<MapEdge> getOutRoads() {
		return outRoads;
	}
	
	@Override
	public String toString() {
		return "(" + Math.round(this.getGeoPoint().getX()) + ", " + Math.round(this.geoPoint.getY()) + ")";
	}
	@Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }

        if (!MapNode.class.isAssignableFrom(obj.getClass())) {
            return false;
        }

        final MapNode other = (MapNode) obj;
        if ((this.geoPoint == null)) {
            return false;
        }
        if (this.geoPoint.getX() != other.geoPoint.getX()
				|| this.geoPoint.getY() != other.geoPoint.getY()) {
        		return false;
        }
        	return true;
    }
}
