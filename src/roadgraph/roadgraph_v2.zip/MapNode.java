package roadgraph;

import java.util.LinkedList;
import java.util.List;

import geography.GeographicPoint;
/**
 * @author Anurag
 * 
 * A class which represents a node of the graph
 * of geographic locations
 * 
 */
public class MapNode {
	private GeographicPoint location;
	private List<MapEdge> streets;
	private List<MapNode> neighbours;
	
	public MapNode(GeographicPoint location) {
		this.location = location;
		this.streets = new LinkedList<MapEdge>();
		this.neighbours = new LinkedList<MapNode>();
	}

	public List<MapNode> getNeighbors() {
		return neighbours;
	}

	void addStreet(MapEdge street) {
		streets.add(street);
	}
	void addNeighbour(MapNode neighbour) {
		neighbours.add(neighbour);
	}
	
	public GeographicPoint getLocation() {
		return location;
	}
	public void setGeoPoint(GeographicPoint geoPoint) {
		this.location = geoPoint;
	}
	public List<MapEdge> getStreets() {
		return streets;
	}
	
	@Override
	public String toString() {
		return "(" + Math.round(this.getLocation().getX()) + ", " + Math.round(this.location.getY()) + ")";
	}

	@Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (!MapNode.class.isAssignableFrom(obj.getClass())) {
            return false;
        }
        final MapNode other = (MapNode) obj;
        if ((this.location == null)) {
            return false;
        }
        if (this.location.getX() != other.location.getX()
				|| this.location.getY() != other.location.getY()) {
        		return false;
        }
        	return true;
    }
}
